module.exports = {
  dbUrl: "mongodb+srv://it22030894:riya2808@cluster0.0pamjf6.mongodb.net/",
};
