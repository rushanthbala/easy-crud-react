const InventoryCoreCard = ({ item }) => {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-semibold mb-2">{item.itemName}</h2>
        <p className="text-gray-600 mb-2">Category: {item.category}</p>
        <p className="text-gray-600 mb-2">Quantity Available: {item.quantityAvailable}</p>
        <p className="text-gray-600 mb-2">Unit Price: {item.UnitPrice}</p>
        <p className="text-gray-600 mb-2">Total Cost: {item.TotalCost}</p>
        <p className="text-gray-600 mb-2">Date: {item.Date}</p>
        <p className="text-gray-600 mb-2">Condition: {item.Condition}</p>
        <p className="text-gray-600 mb-2">Status: {item.status}</p>
      </div>
    );
  };
  export default InventoryCoreCard