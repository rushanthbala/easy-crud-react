export const MenuItems = [
  {
    title: "Login",
    url: "/login",
    cName: "nav-links",
    icon: "fa-solid fa-briefcase",
  },
  {
    title: "Register",
    url: "/register",
    cName: "nav-links",
    icon: "fa-solid fa-briefcase",
  },
];
