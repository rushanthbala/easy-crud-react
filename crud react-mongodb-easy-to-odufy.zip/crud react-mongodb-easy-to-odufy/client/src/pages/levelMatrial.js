import Navbar from "../Components/Navbar";
import Footer from "../Components/Footer";
import LevelMatrialCard from "../Components/levelMatrial/levels";

function LevelMatrial() {
  

  return (
    <>
      <Navbar />
      <br />
      <br />
      <br />
      <LevelMatrialCard />
      <Footer />
    </>
  );
}

export default LevelMatrial;
