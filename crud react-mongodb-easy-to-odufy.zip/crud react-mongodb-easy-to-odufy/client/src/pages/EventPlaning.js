import Hero from "../Components/Hero";
import Navbar from "../Components/Navbar";
import AboutImg from "../assets/course.jpg";
import Footer from "../Components/Footer";
import Course from "../Components/Course";
import ServiceForm from "../Components/service/EventPlaning";

function EventPlainingPage() {
  return (
    <>
      <Navbar />
      <br />
      <br />
      <br /> <br />
      <br />
      <br />
      <ServiceForm />
      <Footer />
    </>
  );
}

export default EventPlainingPage;
