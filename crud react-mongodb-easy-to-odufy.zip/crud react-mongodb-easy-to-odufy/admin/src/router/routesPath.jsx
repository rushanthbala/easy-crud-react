export const allRoutesPath = {
  DASHBOARD: "/",
  COURSE: "/hall",
  INVENTORY:"/inventory",
  EVENT:"/event",
  Transactions:"/transactions",
  LEVEL: "/level",
  ERROR: "/error",
};
