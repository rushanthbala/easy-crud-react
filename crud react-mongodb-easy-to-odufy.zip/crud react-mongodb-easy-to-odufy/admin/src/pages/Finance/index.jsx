import React from "react";
import CourseDataTable from "../../components/layouts/tables/finance/finance";

const FinancePage = () => {

  return (
    <div>
    
      <br />
      <CourseDataTable />
    </div>
  );
};

export default FinancePage;
