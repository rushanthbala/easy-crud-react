import React from "react";
import CourseDataTable from "../../components/layouts/tables/event/event";

const EventPage = () => {

  return (
    <div>
    
      <br />
      <CourseDataTable />
    </div>
  );
};

export default EventPage;
