import React  from 'react';

const Upcoming = () => {
//   const [data, setData] = useState('null');

//   const fetchData = async () => {
//     // Wrap the state update in startTransition
//     startTransition(() => {
//       setData('hello');
//     });
//   };

  return (
    <div>
        Upcoming pages
      {/* <button onClick={fetchData}>Fetch Data</button>
      {data ? <p>{data}</p> : <p>Loading...</p>} */}
    </div>
  );
};

export default Upcoming;
