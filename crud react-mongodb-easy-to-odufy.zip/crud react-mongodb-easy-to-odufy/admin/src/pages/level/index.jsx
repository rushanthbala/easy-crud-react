import React from "react";
import LevelDataTable from "../../components/layouts/tables/level/level";

const LevelPage = () => {
  return (
    <div>
      <br />
      <LevelDataTable />
    </div>
  );
};

export default LevelPage;
