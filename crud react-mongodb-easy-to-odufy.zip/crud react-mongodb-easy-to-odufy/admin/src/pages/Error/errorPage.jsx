const ErrorPages = () => {
  return <h1>Error</h1>;
};

export default ErrorPages;
