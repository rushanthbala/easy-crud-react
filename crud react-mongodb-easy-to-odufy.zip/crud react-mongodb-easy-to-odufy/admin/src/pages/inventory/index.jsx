import React from "react";
import CourseDataTable from "../../components/layouts/tables/inventory/inventory";

const InventoryPage = () => {

  return (
    <div>
    
      <br />
      <CourseDataTable />
    </div>
  );
};

export default InventoryPage;
