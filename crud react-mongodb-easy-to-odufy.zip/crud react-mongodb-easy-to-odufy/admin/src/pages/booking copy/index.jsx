import React from "react";
import CourseDataTable from "../../components/layouts/tables/hall/course";

const CoursePage = () => {

  return (
    <div>
    
      <br />
      <CourseDataTable />
    </div>
  );
};

export default CoursePage;
